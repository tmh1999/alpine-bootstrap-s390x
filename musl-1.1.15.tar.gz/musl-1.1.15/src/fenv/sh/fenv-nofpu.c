#if !__SH_FPU_ANY__ && !__SH4__
#include "../fenv.c"
#endif
