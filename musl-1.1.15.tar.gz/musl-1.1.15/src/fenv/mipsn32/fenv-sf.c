#ifdef __mips_soft_float
#include "../fenv.c"
#endif
