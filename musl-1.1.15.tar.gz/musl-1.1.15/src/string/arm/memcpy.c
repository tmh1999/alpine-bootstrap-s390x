#if __ARMEB__
#include "../memcpy.c"
#endif
