#include "libm.h"

//FIXME
long double complex csinhl(long double complex z)
{
	return csinh(z);
}
