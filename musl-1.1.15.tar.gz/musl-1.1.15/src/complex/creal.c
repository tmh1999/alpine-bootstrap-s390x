#include <complex.h>

double (creal)(double complex z)
{
	return creal(z);
}
